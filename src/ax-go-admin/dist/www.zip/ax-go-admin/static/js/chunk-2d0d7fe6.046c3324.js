/*!
 *  build: admin-pro 
 *  copyright: vue-admin-beautiful.com 1204505056@qq.com 
 *  time: 2021-10-8 16:32:00
 */
(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d0d7fe6"],{"78d3":function(n,a,t){"use strict";t.r(a);var e=function(){var n=this,a=n.$createElement,t=n._self._c||a;return t("div",{staticClass:"upload-container"},[t("vab-upload",{ref:"vabUpload",attrs:{limit:50,name:"file",size:2,url:"/upload"}}),t("el-button",{attrs:{type:"primary"},on:{click:function(a){return n.handleShow()}}},[n._v("模拟上传")])],1)},l=[],o=t("584b"),u={name:"Upload",components:{VabUpload:o["default"]},data:function(){return{}},methods:{handleShow:function(){this.$refs["vabUpload"].handleShow()}}},d=u,r=t("2877"),i=Object(r["a"])(d,e,l,!1,null,null,null);a["default"]=i.exports}}]);
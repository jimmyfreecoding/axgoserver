/*!
 *  build: admin-pro 
 *  copyright: vue-admin-beautiful.com 1204505056@qq.com 
 *  time: 2021-10-8 16:32:00
 */
(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d0c15b6"],{4664:function(e,n,t){"use strict";t.r(n);var a=function(){var e=this,n=e.$createElement,t=e._self._c||n;return t("div",{staticClass:"menu1-1-1-1-container"},[t("el-alert",{attrs:{closable:!1,title:"多级路由 1-1-1-1",type:"success"}},[t("el-input",{model:{value:e.value,callback:function(n){e.value=n},expression:"value"}})],1)],1)},l=[],u={name:"Menu1111",data:function(){return{value:""}}},c=u,s=t("2877"),i=Object(s["a"])(c,a,l,!1,null,"29e3c474",null);n["default"]=i.exports}}]);